<?php

const BR = '<br>';

require '../vendor/autoload.php';

use App\Vehicles\Car;
use App\Vehicles\Motorcycle;
use App\Payment\CreditCardPayment;
use App\RentalSystem\RentalSystem;

// Создаем объекты автомобилей и мотоциклов
$car = new Car("Toyota", "Corolla", 2020, 50.0);
$motorcycle = new Motorcycle("Harley Davidson", "Sportster", 2018, 10.0);

// Создаем систему аренды
$rentalSystem = new RentalSystem();

// Добавляем транспортные средства в систему
$rentalSystem->addVehicle($car);
$rentalSystem->addVehicle($motorcycle);

// Создаем объект оплаты
$payment = new CreditCardPayment("1234-5678-9012-3456", "12/25");

// Арендуем транспортные средства
$rentalSystem->rentVehicle(0, 5, $payment);  // Арендуем автомобиль на 5 дней
echo BR;
$rentalSystem->rentVehicle(1, 3, $payment);  // Арендуем мотоцикл на 3 часа