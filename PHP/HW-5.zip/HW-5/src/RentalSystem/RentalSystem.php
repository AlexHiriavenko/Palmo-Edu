<?php

namespace App\RentalSystem;

use App\Vehicles\Vehicle;
use App\Payment\PaymentMethod;

class RentalSystem {
    private array $vehicles = [];

    // Метод для добавления транспортных средств
    public function addVehicle(Vehicle $vehicle): void {
        $this->vehicles[] = $vehicle;
    }

    // Метод для аренды транспортного средства
    public function rentVehicle(int $vehicleIndex, int $duration, PaymentMethod $paymentMethod): void {
        if (!isset($this->vehicles[$vehicleIndex])) {
            echo "Vehicle not found.\n";
            return;
        }

        $vehicle = $this->vehicles[$vehicleIndex];
        $cost = $vehicle->calculateRentalCost($duration);

        echo $vehicle->getInfo() . "rental cost: {$cost}\n";
        $paymentMethod->processPayment($cost);
    }
}
